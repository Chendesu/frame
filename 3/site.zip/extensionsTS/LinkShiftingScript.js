/*
*  Copyright (C) 1998-2019 by Northwoods Software Corporation. All Rights Reserved.
*/
(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "../release/go", "./LinkShiftingTool"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var go = require("../release/go");
    var LinkShiftingTool_1 = require("./LinkShiftingTool");
    function init() {
        if (window.goSamples)
            window.goSamples(); // init for these samples -- you don't need to call this
        var $ = go.GraphObject.make;
        var myDiagram = $(go.Diagram, 'myDiagramDiv', {
            'undoManager.isEnabled': true
        });
        myDiagram.toolManager.mouseDownTools.add($(LinkShiftingTool_1.LinkShiftingTool));
        myDiagram.nodeTemplate =
            $(go.Node, 'Auto', {
                fromSpot: go.Spot.AllSides, toSpot: go.Spot.AllSides,
                fromLinkable: true, toLinkable: true,
                locationSpot: go.Spot.Center
            }, new go.Binding('location', 'location', go.Point.parse).makeTwoWay(go.Point.stringify), $(go.Shape, { fill: 'lightgray' }), $(go.TextBlock, { margin: 10 }, { fromLinkable: false, toLinkable: false }, new go.Binding('text', 'key')));
        myDiagram.linkTemplate =
            $(go.Link, {
                reshapable: true, resegmentable: true,
                relinkableFrom: true, relinkableTo: true,
                adjusting: go.Link.Stretch
            }, 
            // remember the (potentially) user-modified route
            new go.Binding('points').makeTwoWay(), 
            // remember any spots modified by LinkShiftingTool
            new go.Binding('fromSpot', 'fromSpot', go.Spot.parse).makeTwoWay(go.Spot.stringify), new go.Binding('toSpot', 'toSpot', go.Spot.parse).makeTwoWay(go.Spot.stringify), $(go.Shape), $(go.Shape, { toArrow: 'Standard' }));
        myDiagram.model = new go.GraphLinksModel([
            { key: 'Alpha', location: '0 0' },
            { key: 'Beta', location: '0 100' }
        ], [
            { from: 'Alpha', to: 'Beta' }
        ]);
        myDiagram.addDiagramListener('InitialLayoutCompleted', function (e) {
            // select the Link in order to show its two additional Adornments, for shifting the ends
            var firstlink = myDiagram.links.first();
            if (firstlink !== null)
                firstlink.isSelected = true;
        });
        // Attach to the window for console manipulation
        window.myDiagram = myDiagram;
    }
    exports.init = init;
});
