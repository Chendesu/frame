<pre class="docs-method-signature"><code>element.addPort(port, [opt])</code></pre>

Add a single port, where `port` could be defined as described in section [Port interface](#portinterface)

