<pre class="docs-method-signature"><code>element.addPorts(ports, [opt])</code></pre>

Add array of `ports`. Ports are validated for `id` duplicities, if there is a id collision, no new ports are added, where `port` could be defined as describe in section [Port interface](#portinterface)



