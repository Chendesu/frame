<pre class="docs-method-signature"><code>element.getPortsPositions(groupName)</code></pre>

Returns the positions and the angle of all ports in the group, relatively to the element position. 
