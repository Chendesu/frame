<pre class="docs-method-signature"><code>element.removePort(port, [opt])</code></pre>

Remove a port from an element, where `port` is a port object, or `portId`.
