<pre class="docs-method-signature"><code>element.getPort(id)</code></pre>

Returns the port specified by an `id`. If such a port does not exist the method returns `undefined`.

