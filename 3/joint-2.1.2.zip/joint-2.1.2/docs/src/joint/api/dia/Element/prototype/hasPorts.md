<pre class="docs-method-signature"><code>element.hasPorts()</code></pre>

Check if an element has any ports defined. Returns `boolean`.
