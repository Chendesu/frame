<pre class="docs-method-signature"><code>element.hasPort(id)</code></pre>

Check if an element contains a port with `id`. Returns `boolean`.
