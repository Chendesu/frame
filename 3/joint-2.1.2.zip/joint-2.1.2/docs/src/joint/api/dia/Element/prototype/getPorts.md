<pre class="docs-method-signature"><code>element.getPorts()</code></pre>

Returns an array of all ports on the element. If there is no port an empty array is returned.
