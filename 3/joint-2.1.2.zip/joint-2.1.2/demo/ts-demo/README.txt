Use npm to run this demo.

Navigate to this directory, then run:
$ npm install
$ npm start

During development, use:
$ npm install
$ npm run build-dev
$ npm run dev
