<?php
namespace Common\Model;
use Think\Model\RelationModel;
class CommonModel extends RelationModel {
 
    
    
   
   
}
?>