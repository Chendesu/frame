<?php
// 本类由系统自动生成，仅供测试用途
namespace Home\Controller;
class IndexController extends HomeController {
    public function index(){
	    
       $this->success("马上带你进入示例",U('/demo'));
    }
  
   
}